# SplashPage.py — MyOS 启动画面页
#
# 嵌入主窗口内部显示：学校/车队 logo + 大标题 + 副标题 + loading 呼吸文字 + 柔光晕。
# 动画基于经过时间（elapsed-time），保证任意刷新率下都平滑。
#
# 颜色统一取自 theme.T 的 token（见 ui/theme.py），本文件不写死色值。

import math
import os
from PySide6 import QtCore, QtWidgets, QtGui

from theme import T
from main import APP_VERSION

# 动画时钟间隔（毫秒），约 60fps —— 与显示器刷新率对齐
ANIM_TICK_MS = 16

# logo 资源路径（style/icon 下的学校与车队 logo）
# 学校 logo 有深/浅两套，按当前主题取（见 theme.school_logo()）
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEAM_LOGO_PATH = os.path.join(_ROOT, "style", "icon", "魅影方程式.png")


class SplashPage(QtWidgets.QWidget):
    """嵌入主窗口内部的启动画面，logo 带柔光晕与微缩放呼吸"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("splash-page")
        T.styled(self, "background-color: @bg;")

        # 经过时间驱动动画，避免依赖固定 tick 的累积误差
        self._elapsed = QtCore.QElapsedTimer()
        self._elapsed.start()

        self._breath_timer = QtCore.QTimer(self)
        self._breath_timer.timeout.connect(self._on_anim_tick)
        self._breath_timer.start(ANIM_TICK_MS)

        # logo 资源（加载失败则为 None，绘制时自动跳过）
        self._team_img = self._load_logo(TEAM_LOGO_PATH)
        self._logo_cache = {}   # (name, w, h) -> 预缩放 pixmap
        self._school_img = None
        self._apply_school_logo()
        T.on_change(self._apply_school_logo)

    def _apply_school_logo(self):
        """按当前主题装载学校 logo，并清掉缩放缓存（图换了缓存必须失效）"""
        self._school_img = self._load_logo(T.school_logo())
        self._logo_cache.clear()

    @staticmethod
    def _load_logo(path):
        """加载 logo 图片，失败返回 None"""
        img = QtGui.QImage(path)
        return img if not img.isNull() else None

    def _scaled_logo(self, name, img, w, h):
        """按目标尺寸预缩放 logo（缓存，避免每帧重采样大图）"""
        key = (name, w, h)
        pm = self._logo_cache.get(key)
        if pm is None:
            pm = QtGui.QPixmap.fromImage(img).scaled(
                w, h, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)
            self._logo_cache[key] = pm
        return pm

    @staticmethod
    def _entrance(delay_ms, dur_ms, t_ms):
        """入场进度：错峰延迟后按 smoothstep 归一化到 0..1"""
        e = min(max((t_ms - delay_ms) / dur_ms, 0.0), 1.0)
        return e * e * (3 - 2 * e)

    def showEvent(self, event):
        """每次显示时重启时钟，保证入场动画从可见时刻开始"""
        super().showEvent(event)
        self._elapsed.restart()

    def _on_anim_tick(self):
        """每帧根据经过时间计算呼吸值，触发重绘"""
        self.update()

    def stop_animation(self):
        """停止动画定时器"""
        self._breath_timer.stop()

    def paintEvent(self, event):
        """绘制 splash 页面：柔光晕 + 居中大标题 + 副标题 + loading 呼吸文字"""
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        painter.setRenderHint(QtGui.QPainter.SmoothPixmapTransform)

        w = self.width()
        h = self.height()

        # 经过毫秒数，呼吸周期 2.4s（约 0.42Hz，低于易引发前庭不适的阈值）
        t = self._elapsed.elapsed()
        phase = (t / 2400.0) * 2 * math.pi
        # 用 (sin+1)/2 映射到 0..1，再做 ease-in-out 平滑
        raw = (math.sin(phase) + 1.0) / 2.0
        breath = raw * raw * (3 - 2 * raw)  # smoothstep，比纯 sin 更自然

        cx, cy = w // 2, h // 2 - 150

        # --- 柔光晕：径向渐变模拟材质发光 ---
        glow_radius = 180 + 30 * breath
        glow_grad = QtGui.QRadialGradient(cx, cy, glow_radius)
        glow_color = T.qcolor("accent")
        glow_color.setAlphaF(0.18 * breath + 0.05)
        glow_grad.setColorAt(0, glow_color)
        transparent = T.qcolor("accent")
        transparent.setAlpha(0)
        glow_grad.setColorAt(1, transparent)
        painter.setBrush(QtGui.QBrush(glow_grad))
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawEllipse(QtCore.QPointF(cx, cy), glow_radius, glow_radius)

        # --- MyOS 大标题（左）与学校 LOGO（右）呈左右对称 ---
        # 两者组成一个整体，绕画面中线对称分布；标题微缩放呼吸
        title_font = QtGui.QFont("SF Pro Display", 80, QtGui.QFont.Bold)
        title_font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, -2)
        title_w = int(QtGui.QFontMetricsF(title_font).horizontalAdvance("MyOS"))
        school_h = 60             # 校名（超宽字标）高度
        school_w = (int(school_h * self._school_img.width() / self._school_img.height())
                    if self._school_img is not None else 0)
        gap = 56                  # 标题与校名之间的间距
        pair_w = title_w + gap + school_w   # 组合总宽，绕画面中线对称

        # 大标题（左侧）：微缩放呼吸 + 负字距收紧
        scale = 1.0 + 0.04 * breath
        painter.save()
        painter.translate(cx, cy)
        painter.scale(scale, scale)
        painter.setFont(title_font)
        title_color = T.qcolor("accent")
        title_color.setAlphaF(0.85 + 0.15 * breath)
        painter.setPen(title_color)
        painter.drawText(QtCore.QRect(int(-pair_w / 2), -65, title_w, 130),
                         QtCore.Qt.AlignCenter, "MyOS")
        painter.restore()

        # 学校 LOGO（右侧）：错峰淡入 + 上浮
        if self._school_img is not None:
            a = self._entrance(0, 650, t)
            sx = int(cx + pair_w / 2 - school_w)
            sy = int(cy - school_h / 2 + 16 * (1 - a))
            pm = self._scaled_logo("school", self._school_img, school_w, school_h)
            painter.setOpacity(a)
            painter.drawPixmap(sx, sy, pm)
            painter.setOpacity(1.0)

        # 车队 logo（暂不显示，需要时取消注释即可）
        # if self._team_img is not None:
        #     a = self._entrance(120, 650, t)   # 校名之后错峰入场
        #     # 车队 logo 目标显示高度 150（明显大于校名，突出品牌感），随窗口高度自适应
        #     team_h = int(max(96, min(150, cy - 60)))
        #     tw = int(team_h * self._team_img.width() / self._team_img.height())
        #     tx = int(cx + gap)
        #     ty = int(cy - team_h / 2 + 16 * (1 - a))
        #     pm = self._scaled_logo("team", self._team_img, tw, team_h)
        #     painter.setOpacity(a)
        #     painter.drawPixmap(tx, ty, pm)
        #     painter.setOpacity(1.0)

        # --- 副标题 ---
        sub_font = QtGui.QFont("SF Pro Text", 15)
        sub_font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 1)
        painter.setFont(sub_font)
        sub_color = T.qcolor("fg_dim")
        sub_color.setAlphaF(0.6 + 0.3 * breath)
        painter.setPen(sub_color)
        painter.drawText(QtCore.QRect(0, h // 2, w, 30),
                         QtCore.Qt.AlignCenter, "A03 ")

        # --- loading 文字 ---
        load_font = QtGui.QFont("SF Pro Text", 11)
        load_font.setLetterSpacing(QtGui.QFont.AbsoluteSpacing, 2)
        painter.setFont(load_font)
        load_color = T.qcolor("fg_faint")
        load_color.setAlphaF(0.4 + 0.5 * breath)
        painter.setPen(load_color)
        painter.drawText(QtCore.QRect(0, h // 2 + 40, w, 25),
                         QtCore.Qt.AlignCenter, f"v{APP_VERSION}  —  loading")

        painter.end()
